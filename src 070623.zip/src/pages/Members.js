import React from 'react'
// import Menu from '../component/Menu';
// import Footer from '../component/Footer';
import MembersComp from '../component/MembersComp';
import HeaderMember from '../component/HeaderMember';

const Members = () => {
  return (
    <>
       {/* <Menu /> */}
       <HeaderMember />
       <MembersComp />
       {/* <Footer />      */}
    </>
  )
}

export default Members
