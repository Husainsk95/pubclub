import React from 'react'
// import Menu from '../component/Menu';
import HeaderContact from '../component/HeaderContact';
// import Footer from '../component/Footer';
import ContactForm from '../component/ContactForm';


const Contact = () => {
  return (
    <div>
       {/* <Menu /> */}
       <HeaderContact />
       <ContactForm />
       {/* <Footer />                */}
    </div>
  )
}

export default Contact
