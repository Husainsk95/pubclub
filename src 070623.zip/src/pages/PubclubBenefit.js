import React from 'react'
import Pubclubbenefitheader from '../component/Pubclubbenefitheader'
import Pubclubbenefitsect from '../component/Pubclubbenefitsect'

const PubclubBenefit = () => {
  return (
    <>
    <Pubclubbenefitheader/>
    <Pubclubbenefitsect/>
    </>
  )
}

export default PubclubBenefit