import React from 'react'
import Aboutheader from '../component/Aboutheader'
import Aboutsection from '../component/Aboutsection'

const About = () => {
  return (
    <>
<Aboutheader/>
<Aboutsection/> 
    </>
  )
}

export default About